package bg.sofia.uni.fmi.mjt.glovo.exception;

public class InvalidEntityException extends RuntimeException {
    public InvalidEntityException(String message) {
        super(message);
    }
}
