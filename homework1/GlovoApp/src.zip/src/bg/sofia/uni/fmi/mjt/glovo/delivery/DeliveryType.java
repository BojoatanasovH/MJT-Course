package bg.sofia.uni.fmi.mjt.glovo.delivery;

public enum DeliveryType {
    CAR(5, 3),

    BIKE(3, 5);

    DeliveryType(double pricePerKilometer, int timePerKilometer) {
    }
}
